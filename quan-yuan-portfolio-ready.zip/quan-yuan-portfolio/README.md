# Quan Yuan Portfolio

Upload the files in this folder to the root of the GitHub repository.

Structure:

- index.html
- images/
  - space-industrial.jpg
  - flowers-and-bird.jpeg
  - space-exploration.jpeg
  - astronaut-and-science.jpg

The red logo image is intentionally not included.
